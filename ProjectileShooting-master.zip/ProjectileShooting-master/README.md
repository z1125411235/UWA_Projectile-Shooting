# ProjectileShooting
Project demonstrating in Unity how to fire a projectile at a target by either specifying its initial velocity or initial angle. Also draws out the projectile's expected trajectory.

Projectile physics calculations are inside the `ProjectileMath.cs` file.

![](http://i.imgur.com/ORco4k3.gif)
